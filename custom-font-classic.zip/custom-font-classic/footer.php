<main>
	<footer class="site-footer">
		<p>
			<?php
			printf(
				/* translators: %s: WordPress. */
				esc_html__( 'Footer', 'custom-font-classic' ),
				'WordPress'
			);
			?>
		</p>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
