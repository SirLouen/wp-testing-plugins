<?php

if ( ! function_exists( 'custom_font_classic_setup' ) ) {
	function custom_font_classic_setup() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

		register_nav_menus( array(
			'primary' => __( 'Primary Menu', 'custom-font-classic' ),
		) );
	}
}
add_action( 'after_setup_theme', 'custom_font_classic_setup' );

if ( ! function_exists( 'custom_font_classic_scripts' ) ) {
	function custom_font_classic_scripts() {
		$theme = wp_get_theme();

		wp_enqueue_style(
			'custom-font-classic-style',
			get_stylesheet_uri(),
			array(),
			$theme->get( 'Version' )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'custom_font_classic_scripts' );
