<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'custom-font-classic' ); ?></a>
<div class="site-wrapper">
	<header class="site-header">
		<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
		<p class="site-description"><?php bloginfo( 'description' ); ?></p>
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<nav class="primary-menu" aria-label="<?php esc_attr_e( 'Primary menu', 'custom-font-classic' ); ?>">
				<?php
					wp_nav_menu( array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'      => 'menu',
						'depth'           => 1,
					) );
				?>
			</nav>
		<?php endif; ?>
	</header>
	<main id="content">
