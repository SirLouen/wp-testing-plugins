<?php

global $wp_query;

get_header();

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();
		?>
		<article <?php post_class( 'post-card' ); ?>>
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<p class="meta">
				<?php
					printf(
						/* translators: 1: post date, 2: post author */
						esc_html__( 'Posted %1$s by %2$s', 'custom-font-classic' ),
						get_the_date(),
						get_the_author()
					);
				?>
			</p>
			<div class="entry-content">
				<?php
					the_excerpt();
				?>
			</div>
			<a class="read-more" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'custom-font-classic' ); ?></a>
		</article>
		<?php
	endwhile;

	the_posts_pagination();
else :
	?>
	<article class="post-card">
		<h2><?php esc_html_e( 'Nothing here yet', 'custom-font-classic' ); ?></h2>
		<p><?php esc_html_e( 'Add a post.', 'custom-font-classic' ); ?></p>
	</article>
	<?php
endif;

get_footer();
