import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';

/**
 * @return {import('react').JSX.Element}
 */
export default function save() {
	const blockProps = useBlockProps.save();

	return (
		<p { ...blockProps }>
			{ __( 'Test Navigation Child – saved content', 'test-navigation-child' ) }
		</p>
	);
}
